# 📦 synker

**synker** is a Python package for generating synthetic datasets based on real data using Kernel Density Estimation (KDE) methods.

It supports:
- Bandwidth selection (Scott's and Silverman's rules)
- 2D KDE
- Synthetic data generation
- Kullback–Leibler (KL) divergence evaluation
- Cumulative Kullback–Leibler (CKL) divergence evaluation
- Arbitrary probability interval selection for data filtering and analysis

---

## 🚀 Features

- **Bandwidth Estimation** using Scott's and Silverman's rules  
- **2D Kernel Density Estimation**
- **Synthetic Data Generation** based on KDE
- **KL Divergence Calculation** to compare real and synthetic data
- **CKL Divergence Calculation** to compare real and synthetic data
- **Probability Interval Filtering (`pinkde`)**: Identify data points within specified probability ranges
- Modular and extensible design for ease of integration

---

## 🧠 Installation

Clone the repository and install the package locally:

```bash
git clone https://github.com/dhaselib/synker
cd synker
pip install .
```

## ✅ Testing

A test files `test1.py`, `test2.py`, and `test2.py` are included to validate core functionalities like bandwidth estimation, KDE, synthetic generation, KL divergence, CKL divergence, and the `pinkde` module.


### Tests cover:
- Scott and Silverman bandwidth estimation  
- 2D KDE result structure  
- Synthetic data shape and boundary validation  
- Non-negative KL divergence check  
- CKL divergence check 
- Probability interval selection with `pinkde`  

---

## 📁 Project Structure

```
synker/
├── __init__.py
├── scott.py
├── silverman.py
├── kde.py
├── synthetic.py
├── kl_div.py
├── ckl-div.py
├── pinkde.py
├── tests/
│   └── test1.py
|   └── test2.py
|   └── test3.py 
└── README.md
```

---

## 📜 License

This project is licensed under the **MIT License**:

```
MIT License

Copyright (c) 2025 Danial Haselibozchaloee

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
```